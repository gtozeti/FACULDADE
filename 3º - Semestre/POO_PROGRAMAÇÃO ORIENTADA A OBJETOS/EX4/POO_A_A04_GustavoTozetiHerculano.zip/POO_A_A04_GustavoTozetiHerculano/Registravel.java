// Declaração da interface Registravel
public interface Registravel {
    
    // Metódo sem implementação
    public abstract String getNumeroRegistro();

}
