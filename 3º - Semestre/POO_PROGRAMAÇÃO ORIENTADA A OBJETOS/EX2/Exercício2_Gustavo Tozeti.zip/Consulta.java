import java.util.ArrayList;

public class Consulta {
    
    private ArrayList<Paciente> paciente;

    public static void main(String[] args) {
        Consulta vc = new Consulta();
        vc.validaPaciente();
        vc.cadastraConsulta();
    }


    public void validaPaciente(){

    }

    public void cadastraConsulta(){

    }
}
