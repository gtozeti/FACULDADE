package br.senac.tads.dsw.ado03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ado03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
