package br.senac.tads.dsw.exemplosspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemplosSpringSessaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExemplosSpringSessaoApplication.class, args);
    }

}
