package br.senac.tads.dsw.exemplosspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ExemplosSpringSessaoApplicationTests {

  @Test
  public void contextLoads() {}

}
