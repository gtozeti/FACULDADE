package br.senac.tads.dsw.musicas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMusicasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMusicasApplication.class, args);
	}

}
